//
//  ViewController.swift
//  MenuBar
//
//  Created by FCI on 26/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var MenuBar: UIButton!
    @IBOutlet var InsuranceMenu: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Style the menu bar button
        MenuBar.layer.cornerRadius = MenuBar.frame.height / 2
        
        // Initialize all menu items
        InsuranceMenu.forEach { btn in
            btn.layer.cornerRadius = btn.frame.height / 2
            btn.isHidden = true
            btn.alpha = 0
        }
    }

    @IBAction func ClickForItems(_ sender: UIButton) {
        let shouldShow = InsuranceMenu.first?.isHidden ?? true
        InsuranceMenu.forEach { btn in
            UIView.animate(withDuration: 0.3, animations: {
                btn.alpha = shouldShow ? 1 : 0
            }, completion: { _ in
                btn.isHidden = !shouldShow
            })
        }
    }

    @IBAction func ItemPress(_ sender: UIButton) {
        // Handle individual menu item presses
        print("Pressed: \(sender.currentTitle ?? "Unknown Item")")
    }
}
